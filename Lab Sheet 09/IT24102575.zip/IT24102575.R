setwd("C:\\Users\\Pathum\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102575")

#Q1
#Part 1 

y <- rnorm(24,mean =45,sd=2 )
y

#Part 2

t.test(y,mu=46,alternative ="less")